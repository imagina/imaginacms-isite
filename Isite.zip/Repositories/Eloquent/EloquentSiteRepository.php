<?php

namespace Modules\Isite\Repositories\Eloquent;

use Modules\Isite\Repositories\SiteRepository;
use Modules\Core\Repositories\Eloquent\EloquentBaseRepository;

class EloquentSiteRepository extends EloquentBaseRepository implements SiteRepository
{
}

<?php

namespace Modules\Isite\Repositories;

use Modules\Core\Repositories\BaseRepository;

interface SiteRepository extends BaseRepository
{
}
